package com.example.alunos.fatorial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText leitura = (EditText) findViewById(R.id.numero);
        Button botao1 = (Button) findViewById(R.id.botao);
        final TextView resultado = (TextView) findViewById(R.id.fatorial);
        botao1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = Integer.parseInt(leitura.getText().toString());
                int x=1,y=1;

                while (x<= i){
                    y = y * x;
                    x++;
                }

                resultado.setText("O resultado da fatoração é: "+ y);
            }
        });
    }
}
